<!DOCTYPE html>
<html>

	<head>
	
		<meta charset="utf-8">
		<title>Brandon Johnson Planetary Scientist | Brand-On Johns-On</title>
		
		<!-- Set Keywords & Description -->
		<meta name="keywords" content="" />
		<meta name="description" content="" />

		<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico" />
		
		<!-- Set Viewport Options -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;"/>
		<meta name="apple-mobile-web-app-capable" content="yes" />
		
		<!-- Include Fonts -->	
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600italic,600,700,700italic" rel="stylesheet" type="text/css">		
		
		<!-- Include Stylesheets -->
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="assets/css/edits.css" />

		<!-- Include Libraries -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="assets/js/lib/waypoints.min.js"></script>
		<script src="assets/js/lib/jquery.easing.min.js"></script>
		<script src="assets/js/lib/modernizr-2.6.2.min.js"></script>
		<script src="assets/js/lib/respond.min.js"></script>

	</head>
	
	<body class="loading">

		<div class="loader">

			<div class="percent">00000</div>

		</div><!-- end .loading -->	

		<nav class="navigation">

			<a href="javascript:Navigation.scrollTo('.hero');" class="active"><span></span></a>
			<a href="javascript:Navigation.scrollTo('.about');"><span></span></a>
			<a href="javascript:Navigation.scrollTo('.hydrocode');"><span></span></a>
			<a href="javascript:Navigation.scrollTo('.interests');"><span></span></a>
			<a href="javascript:Navigation.scrollTo('.publications');"><span></span></a>
			<a href="javascript:Navigation.scrollTo('.grail');"><span></span></a>

		</nav><!-- end .navigation -->
	
		<header class="hero">

			<div class="steez-line"></div>

			<div class="number">00001</div>

			<div class="container">

				<div class="title">Planetary Scientist</div>

				<div class="logo"><a href=""><img src="assets/img/logo.svg" alt="logo"/></a></div>

				<h1>BRAND-<br/>
				ON<br/>
				JOHNS-<br/>
				ON</h1>

			</div><!-- end .container -->	

		</header><!-- end header -->

		<div id="viewport">

			<div class="always-on">

				<div class="on">
					<div class="on-close"><a href="javascript:Brandon.toggleOn();">Close</a></div>
					<div class="on-hold">
						<img src="assets/img/alwayson.svg" alt="alwayson"/>
					</div>
				</div><!-- end .on -->

			</div><!-- end .always-on -->

			<section class="about" id="about">

				<div class="number">00002</div>

				<div class="container">

					<div class="asteroid asteroid-1"><img src="assets/img/about-asteroid1.png" alt="asteroid"/></div>
					<div class="asteroid asteroid-2"><img src="assets/img/about-asteroid2.png" alt="asteroid"/></div>
					<div class="asteroid asteroid-3"><img src="assets/img/about-asteroid3.jpg" alt="asteroid"/></div>

					<h3>
						Always On
						<span>Brandon Johnson</span>
					</h3>	

					<div class="alwayson">

						<div class="asteroid-main"><img src="assets/img/about-asteroid-main.png" alt="asteroid"/></div>
						<div class="line-steez"></div>
						<div class="line-steez steez-2"></div>
						<div class="rectangle"></div>

					</div><!-- end .alwayson -->

					<div class="text">
						<p>

							I am an Associate Professor in the <a href="https://www.eaps.purdue.edu/" target="_blank">Department of Earth, Atmospheric, and Planetary Sciences</a> at Purdue University. My research is focused mainly on impact cratering, which is arguably the most pervasive geologic process in the solar system.

						</p>

						<div class="scroll"><a href="javascript:Navigation.scrollTo('.hydrocode');"><img src="assets/img/icon-arrow.svg" alt="arrow" class="svg-raw"/></a></div>
					</div><!-- end .text -->

				</div><!-- end .container -->

			</section><!-- end .about -->

			<section class="hydrocode" id="hydrocode">

				<div class="number">00003</div>

				<div class="container">

					<div class="row">

						<div class="column-2">

							<h2>Hydrocode</h2>

							<p>
								In my group we use numerical models called hydrocodes to study the formation of impact craters and impact processes. Currently we are simulating the formation of large basins throughout the solar system.
							</p>

							<div class="impact">

								<a href="https://www.youtube.com/watch?v=OMq6PycfdjI&feature=youtu.be" target="_blank">
									<img src="assets/img/icon-play.svg" alt="play" class="svg-raw"/>
									<span>IMPACT DEMO</span><br/>
									Play Video
								</a>	

							</div><!-- end .impact -->

						</div><!-- end .column-2 -->

						<div class="column-2">

							<div class="graph">
								<img src="assets/img/hydrocode-graph.svg" alt="graph"/>
								<div class="graph-line"></div>
								<div class="graph-line line-2"></div>
								<div class="graph-line line-3"></div>
								<div class="graph-line line-4"></div>
							</div><!-- end .graph -->

						</div><!-- end .column-2 -->

					</div><!-- end .row -->

					<div class="alwayson">

						<b>ON</b> <span>|</span> <a href="javascript:Brandon.toggleOn();">OFF</a>

					</div><!-- end .alwayson -->

				</div><!-- end .container -->

			</section><!-- end .hydrocode -->

			<section class="interests" id="interests">

				<div class="number">0004</div>

				<div class="container">

					<div class="line-steez"></div>

					<div class="profile">

						<a href="http://scholar.google.com/citations?user=vScvJjYAAAAJ&hl=en" target="_blank">
							<img src="assets/img/interests-profile.jpg" alt="brandon"/><br/>
							Google Scholar Profile
						</a>

					</div><!-- end .profile -->

					<div class="text">

						Other interest include the formation of distal impact ejecta; impact jetting; spallation; the impact origin of chondrules; solar system dynamics; impacts in extra-solar systems; the reduction of friction during long run-out landslides and earthquakes; the breakup of comets; crater erasure; understanding the lunar gravity field; and other geophysical problems that pique my curiosity.

					</div><!-- end .text -->

					<div class="scroll"><a href="javascript:Navigation.scrollTo('.publications');"><img src="assets/img/icon-arrow.svg" alt="arrow" class="svg-raw"/></a></div>

				</div><!-- end .container -->

			</section><!-- end .interests -->

			<section class="publications" id="publications">

				<div class="number">0005</div>

				<div class="container">

					<div class="line-x"></div>

					<div class="line-x-parallax"><div class="line-x line-x-2"></div></div>

					<div class="line-steez"></div>

					<div class="line-steez line-steez-2"></div>

					<div class="text">

						<div class="title">
							15 of 37<br/>
							<span>Publications by Brandon Johnson</span>
						</div><!-- end .title -->

						<h2>Publicati-<br/>
						On</h2>

						<div class="row">

							<div class="column-3">

								<p><span class="highlight">B. C. Johnson</span>, M. M. Sori, A. J. Evans. Ferrovolcanism on metal worlds and the origin of pallasites. Nature Astronomy (2019).</p>
								<p>Wiggins, S. E., <span class="highlight">B. C. Johnson</span>, T. J. Bowling, H. J. Melosh, E. A. Silber. Impact Fragmentation and the Development of the Deep Lunar Megaregolith. J. Geophys. Res. Planets 124, 941–957 (2019).</p>
								<p><span class="highlight">Johnson, B. C.</span>, J. C. Andrews-Hanna, G. S. Collins, A. M. Freed, H. J. Melosh, M. T. Zuber. Controls on the formation of lunar multiring basins. J. Geophys. Res. Planets 123, 3035–3050 (2018).</p>
								<p><span class="highlight">Johnson, B. C.</span>, C. S. Campbell.  Drop height and volume control the mobility of long runout landslides on the Earth and Mars. Geophys. Res. Lett. 44, 12091–12097 (2017). </p>
								<p><span class="highlight">Johnson, B. C.</span>, K. J. Walsh, D. A. Minton, A. N. Krot, H. F. Levison. Timing of the formation and migration of giant planets as constrained by CB chondrites. Science Advances 2, e1601658 (2016).</p>
							</div><!-- end .column-3 -->

							<div class="column-3">	
								<p><span class="highlight">Johnson, B. C.</span>, D. M. Blair, G. S. Collins, H. J. Melosh, A. M. Freed, G. J. Taylor, J. W. Head, M. A. Wieczorek, J. C. Andrews-Hanna, F. Nimmo, J. T. Keane, K. Miljković, J. M. Soderblom, M. T. Zuber. Formation of the Orientale Lunar Multiring Basin. Science 354, 441–444 (2016).</p>
								<p><span class="highlight">Johnson, B. C.</span>, T. J. Bowling, A. J. Trowbridge, A. M. Freed. Formation of the Sputnik Planum basin and the thickness of Pluto’s subsurface ocean. Geophys. Res. Lett. 43, 10068–10077 (2016).</p>
								<p><span class="highlight">Johnson, B. C.</span>, C. S. Campbell, H. J. Melosh. The reduction of friction in long runout landslides as an emergent phenomenon. J. Geophys. Res. Earth Surf. 121, 881–889 (2016). </p>
								<p><span class="highlight">Johnson, B. C.</span>, D. A. Minton, H. J. Melosh, M.T. Zuber. Impact jetting as the origin of chondrules. Nature 517, 339–341 (2015).</p>
								<p>Freed, A. M., <span class="highlight">B. C. Johnson</span>, D. M. Blair, H. J. Melosh, G. A. Neumann, R. J. Phillips, S. C. Solomon, M. A. Wieczorek, M. T. Zuber. The Formation of Lunar Mascon Basins from Impact to Contemporary Form J. Geophys. Res. Planets 119, JE004657 (2014).</p>
							</div><!-- end .column-3 -->

							<div class="column-3">	
								<p><span class="highlight">Johnson, B. C.</span>, T. J. Bowling, H. J. Melosh. Jetting during vertical impacts of spherical projectiles. Icarus 238, 13–22 (2014).</p>
								<p><span class="highlight">Johnson, B. C.</span>, H. J.  Melosh. Formation of melt droplets, melt fragments, and accretionary impact lapilli during a hypervelocity impact. Icarus 228, 347–363 (2014).</p>
								<p>Melosh, H. J., A. M. Freed, <span class="highlight">B. C. Johnson</span>, D. M. Blair, J. C. Andrews-Hanna, G. A. Neumann, R. J. Phillips, D. E. Smith, S. C. Solomon, M. A. Wieczorek, M. T. Zuber. The Origin of Lunar Mascon Basins. Science 340, 1552–1555 (2013). </p>
								<p><span class="highlight">Johnson, B. C.</span>, H. J. Melosh. Impact spherules as a record of an ancient heavy bombardment of Earth. Nature 485, 75–77 (2012).</p>
								<p><span class="highlight">Johnson, B. C.</span>, H. J. Melosh. Formation of spherules in impact produced vapor plumes. Icarus 217, 416–430 (2012).</p>
							</div><!-- end .column-3 -->

						</div><!-- end .row -->

						<div class="contact">

							<a href="mailto:bcjohnson@purdue.edu"><img src="assets/img/publications-contact.svg" alt="contact" class="svg-raw"/></a>

						</div><!-- end .contact -->

					</div>

				</div><!-- end .container -->

			</section><!-- end .publications -->

			<section class="grail" id="grail">

				<div class="number">0006</div>

				<div class="container">

					<h2>
						<span>Brand-</span>
						On
					</h2>

					<div class="planet">
						<div class="world-steez-ring"><img src="assets/img/grail-steez-ring.svg" alt="steez"/></div>
						<div class="world-steez"><img src="assets/img/grail-circle.svg" alt="steez"/></div>
						<div class="world"><img src="assets/img/grail-world.png" alt="world"/></div>
					</div><!-- end .planet -->

					<div class="text">

						<h3>Grail</h3>
						<p>I was lucky enough to see the launch of the NASA’s GRAIL mission and have presented at several team meetings. One of my driving goals is to be an investigator on a successful space mission.</p>

						<div class="vert-line"></div>

					</div><!-- end .text -->

					<div class="cv">

						<!-- <a href="">Latest News</a> <span>|</span>  --><a href="https://www.eaps.purdue.edu/people/faculty-pages/vitae/johnson-b.pdf" target="_blank">Download CV</a>

					</div><!-- end .cv -->

					<div class="scroll"><a href="javascript:Navigation.scrollTo('.footer');"><img src="assets/img/icon-arrow.svg" alt="arrow" class="svg-raw"/></a></div>

					<div class="logo"><a href="index.php"><img src="assets/img/logo.svg" alt="logo"/></a></div>

				</div><!-- end .container -->

			</section><!-- end .grail -->

		</div><!-- end #viewport -->

		<footer class="footer">

			<div class="container">

				<p><b>Brandon C. Johnson</b><br/>Associate Professor</p>

				<p>
				Department of Earth, Atmospheric, and Planetary Sciences<br/>
				Purdue University<br/>
				550 Stadium Mall Drive<br/>
				West Lafayette, IN 47907<br/>
				</p>

				<p>
				<a href="mailto:bcjohnson@purdue.edu">bcjohnson@purdue.edu</a>
				</p>

				<p>Site by <a href="https://elegantseagulls.com/" target="_blank">Elegant Seagulls</a></p>

			</div>

		</footer><!-- end footer -->
		
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

		  ga('create', 'UA-56522015-1', 'auto');
		  ga('send', 'pageview');

		</script>

		<!-- Include Scripts -->
		<script src="assets/js/brandon.Loader.js"></script>
		<script src="assets/js/brandon.Parallax.js"></script>
		<script src="assets/js/brandon.Navigation.js"></script>
		<script src="assets/js/brandon.js"></script>

	</body>

</html>